package lk.ijse.StudentMS.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LoginFormController<userName> {

    public AnchorPane pane;
    public Label lblName;
    @FXML
    private TextField txtName;
    @FXML
    private TextField txtPassword;

    public Label lblNameWarning;
    @FXML
    private Label lblPasswordWarning;

    private Matcher nameMatcher;
    private Matcher passwordMatcher;

    private void setPatterns() {
        Pattern namePattern = Pattern.compile("^[a-zA-Z0-9]{4,}$");
        nameMatcher = namePattern.matcher(txtName.getText());
    }
    public void initialize() {
        setPatterns();
    }



        @FXML
public  void loginOnAction(ActionEvent event) throws IOException {
        //regex
            if(nameMatcher.matches()) {
                System.out.println("register action now perform");
            }else {
                txtName.requestFocus();
              //  txtName.setFocusColor(Paint.valueOf("Red"));
                lblName.setText("invalid user name");
            }
        }
    public void txtNameKeyTypedOnAction(KeyEvent keyEvent) {

        lblName.setText("");
       //txtName.setFocusColor(Paint.valueOf("Blue"));
        //txtName.setText(String.valueOf(Paint.valueOf("Blue")));

        Pattern namePattern = Pattern.compile("^[a-zA-Z0-9]{4,}$");
        nameMatcher = namePattern.matcher(txtName.getText());

        if (!nameMatcher.matches()) {
//            System.out.println(txtUserName.getText());
            txtName.requestFocus();
          //  txtName.setFocusColor(Paint.valueOf("Red"));
           // txtName.setText(String.valueOf(Paint.valueOf("Red")));
            lblName.setText("invalid user name");
        }


    }  /*     String password = txtPassword.getText();
       String userName = txtName.getText();

        User user=new User();
        user.setUserName(userName);

        try {
        boolean checkUser = false;
        try {
            checkUser = UserModel.checkUser(user);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        if(checkUser) {
               String DBrole = user.getRole();
               String DBpassword = user.getPassword();


                if (DBrole.equals("Admin")) {
                    if (password.equals(DBpassword)) {
                        Stage stage = (Stage) pane.getScene().getWindow();
                        try {
                            stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/lk/ijse/StudentMS/view/AdminForm.fxml"))));
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        stage.show();
                    }
                } else if (DBrole.equals("Manager")) {
                    Stage stage = (Stage) pane.getScene().getWindow();
                    try {
                        stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/lk/ijse/StudentMS/view/ManagerForm.fxml"))));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    stage.show();
                } else if (DBrole.equals("Teacher")) {
                    Stage stage = (Stage) pane.getScene().getWindow();
                    try {
                        stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/lk/ijse/StudentMS/view/TeacherForm.fxml"))));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    stage.show();
                }
            }

        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }

*/


//       //loku form ain wela eke udta ekk load wenna
//        Stage stage= (Stage) pane.getScene().getWindow();
//        stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/lk/ijse/StudentMS/view/AdminForm.fxml"))));
//        stage.show();
//    }

    public void FogotPassword(ActionEvent actionEvent) {

    }

    public void CreateNAOnAction(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage) pane.getScene().getWindow();
        stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/lk/ijse/StudentMS/view/CreateAccountForm.fxml"))));
        stage.show();

    }


    public void LoginOnAction(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage) pane.getScene().getWindow();
        stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/lk/ijse/StudentMS/view/AdminForm.fxml"))));
        stage.show();
    }


     /* String password = txtPassword.getText();
        String userName = txtName.getText();

        User user=new User();
        user.setUserName(userName);


        try {
        boolean checkUser = false;
        try {
            checkUser = UserModel.checkUser(user);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        if(checkUser) {
                String DBrole = user.getRole();
                String DBpassword = user.getPassword();


                if (DBrole.equals("Admin")) {
                    if (password.equals(DBpassword)) {
                        Stage stage = (Stage) pane.getScene().getWindow();
                        try {
                            stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/lk/ijse/StudentMS/view/AdminForm.fxml"))));
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        stage.show();
                    }
                } else if (DBrole.equals("Manager")) {
                    Stage stage = (Stage) pane.getScene().getWindow();
                    try {
                        stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/lk/ijse/StudentMS/view/ManagerForm.fxml"))));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    stage.show();
                } else if (DBrole.equals("Teacher")) {
                    Stage stage = (Stage) pane.getScene().getWindow();
                    try {
                        stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/lk/ijse/StudentMS/view/TeacherForm.fxml"))));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    stage.show();
                }
            }

        } catch (SQLException | ClassNotFoundException | IOException throwables) {
            throwables.printStackTrace();
        }

    }*/
}
