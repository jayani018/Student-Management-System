package lk.ijse.StudentMS.controller;

import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import lk.ijse.StudentMS.db.DBConnection;
import lk.ijse.StudentMS.model.SubjectModel;
import lk.ijse.StudentMS.model.TeacherModel;
import lk.ijse.StudentMS.to.Subject;
import lk.ijse.StudentMS.to.Teacher;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ManageTeacherFormController {
    public AnchorPane pane;
    public TableView Teacher;
    public TableColumn TID;
    public TableColumn NIC;
    public TableColumn Name;
    public TableColumn Address;
    public TableColumn Email;
    public TableColumn CNumber;
    public TableColumn Salary;
    public JFXTextField Search;
    public JFXTextField txtId;
    public JFXTextField txtNIC;
    public JFXTextField txtSalary;
    public JFXTextField txtName;
    public JFXTextField txtEmail;
    public JFXTextField txtContactNo;
    public JFXTextField txtAddress;
    public JFXComboBox combSubId;
    public TableColumn SUBID;
    public TableColumn CNNumber;
    public TableView tblTeacher;

    public void btnAdd(ActionEvent actionEvent) {
        String subId = String.valueOf(combSubId.getValue());
        String id = txtId.getText();
        String NIC = txtNIC.getText();
        String name = txtName.getText();
        String address = txtAddress.getText();
        String contactNo = txtContactNo.getText();
        String email = txtEmail.getText();
        double salary = Double.parseDouble(txtSalary.getText());
        Teacher teacher = new Teacher(id, subId, NIC, name, address, contactNo, email, salary);
        try {
            boolean addTeacher = TeacherModel.addTeacher(teacher);
            if (addTeacher) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "added");
                alert.show();
            }

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

       /* Parent parent = FXMLLoader.load(getClass().getResource("/lk/ijse/StudentMS/view/SuccessfullForm.fxml.fxml"));
        pane.getChildren().clear();
        pane.getChildren().add(parent);*/
       /* Stage stage = (Stage) pane.getScene().getWindow();
        stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/lk/ijse/StudentMS/view/SuccessfulForm.fxml.fxml"))));
        stage.show();*/

    }

    public void btnUpdate(ActionEvent actionEvent) {
        String subjectId = String.valueOf(combSubId.getValue());
        String studentId = txtId.getText();
        String NIC = txtNIC.getText();
        String name = txtName.getText();
        String address = txtAddress.getText();
        String contactNo = txtContactNo.getText();
        String email = txtEmail.getText();
        double salary = Double.parseDouble(txtSalary.getText());

        Teacher teacher = new Teacher(studentId, subjectId, NIC, name, address, contactNo, email, salary);

        try {
            boolean updateTeacher = TeacherModel.updateTeacher(teacher);
            if (updateTeacher) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Update is successful");
                alert.show();
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR, "error");
                alert.show();
            }

        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

    public void btnDelete(ActionEvent actionEvent) {
            String TID = txtId.getText();
            Teacher teacher = new Teacher();
            teacher.setTID(TID);
            try {
                boolean deleteTeacher = TeacherModel.deleteTeacher(teacher);
                if (deleteTeacher) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION, "Delete is successful");
                    alert.show();
                    txtId.setText(null);
                    txtNIC.setText(null);
                    txtName.setText(null);
                    txtAddress.setText(null);
                    txtContactNo.setText(null);
                    txtEmail.setText(null);
                    txtSalary.setText(null);

                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR, "Error");
                    alert.show();
                }

            } catch (SQLException | ClassNotFoundException throwables) {
                throwables.printStackTrace();
            }
        }


      /*  private void cmbLoadData () {
            try {

                ArrayList<Subject> arrayList = SubjectModel.loadSubject();

                String[] teacher = new String[arrayList.size()];

                for (int i = 0; i < arrayList.size(); i++) {
                    SubjectIds[i] = arrayList.get(i).getSUBID();
                }

                combSubId.getItems().setAll(SubjectIds);

            } catch (SQLException | ClassNotFoundException throwables) {
                throwables.printStackTrace();
            }
        }
        public void initialize () {
            cmbLoadData();
        }
*/

    ObservableList<Teacher> obs = FXCollections.observableArrayList();
    private ObservableList tableLoad(ObservableList<Teacher> obs) {
        try {
            Connection connection = DBConnection.getdBConnection().getConnection();
            PreparedStatement pst = connection.prepareStatement("select * from Teacher");
            ResultSet resultSet = pst.executeQuery();
            while (resultSet.next()){
                this.obs.add(new Teacher(
                                resultSet.getString(1),
                                resultSet.getString(2),
                                resultSet.getString(3),
                                resultSet.getString(4),
                                resultSet.getString(5),
                                resultSet.getString(6),
                                resultSet.getString(7),
                                resultSet.getDouble(8)
                        )

                );
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
        return obs;
    }
    private void tableInit(){
        TID.setCellValueFactory(new PropertyValueFactory<>("Teacher ID"));
        SUBID.setCellValueFactory(new PropertyValueFactory<>("Subject ID"));
        NIC.setCellValueFactory(new PropertyValueFactory<>("NIC"));
        Name.setCellValueFactory(new PropertyValueFactory<>("Name"));
        Address.setCellValueFactory(new PropertyValueFactory<>("Address"));
        CNNumber.setCellValueFactory(new PropertyValueFactory<>("Contact No"));
        Email.setCellValueFactory(new PropertyValueFactory<>("Email"));
        Salary.setCellValueFactory(new PropertyValueFactory<>("Salary"));

        tblTeacher.setItems(tableLoad(obs));
    }


    private void cmbLoadData() throws SQLException, ClassNotFoundException {
        ArrayList<Subject> arrayList = SubjectModel.loadSubject();
        for (Subject sub : arrayList) {
            combSubId.getItems().add(sub.getSUBID());
        }
    }

    public void initialize() {
        try {
            cmbLoadData();
                tableInit();
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }


    public void btnSearch(ActionEvent actionEvent) {
    }

    public void txtSearchOnAction(ActionEvent actionEvent) {
    }
}