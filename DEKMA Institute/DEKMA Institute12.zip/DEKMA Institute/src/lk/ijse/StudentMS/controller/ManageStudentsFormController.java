package lk.ijse.StudentMS.controller;

import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import lk.ijse.StudentMS.model.EmployeeModel;
import lk.ijse.StudentMS.model.StudentModel;
import lk.ijse.StudentMS.to.Employee;
import lk.ijse.StudentMS.to.Student;

import java.sql.SQLException;
import java.util.ArrayList;

public class ManageStudentsFormController {


    public TableColumn Stream;
    public TableColumn StudentId;
    public TableColumn NIC;
    public TableColumn Name;
    public TableColumn Address;
    public TableColumn Email;
    public TableColumn CNumber;
    public TableColumn EY;
    public AnchorPane pane;
    public TableView Student;
    public JFXTextField Search;
    public JFXTextField txtID;
    public JFXTextField txtNIC;
    public JFXTextField txtName;
    public JFXTextField txtAdress;
    public JFXTextField txtEmail;
    public JFXTextField txtCNo;
    public JFXTextField txtEY;
    public JFXTextField txtStream;
    public JFXComboBox<String> combEmployeeId;
    public TextField text;





    public void btnUpdateStudent(ActionEvent actionEvent) {
        String employeeId =String.valueOf(combEmployeeId.getValue()) ;
        String studentId = txtID.getText();
        String NIC = txtNIC.getText();
        String stream = txtStream.getText();
        String examYear = txtEY.getText();
        String name = txtName.getText();
        String address = txtAdress.getText();
        String contactNo = txtCNo.getText();
        String email = txtEmail.getText();

        lk.ijse.StudentMS.to.Student student = new Student(studentId,employeeId,NIC,stream,examYear,name,address,contactNo,email);

        try {
            boolean updateStudent = StudentModel.updateStudent(student);
            if (updateStudent) {
                Alert alert=new Alert(Alert.AlertType.INFORMATION,"Update is successful");
                alert.show();
            }else{
                Alert alert=new Alert(Alert.AlertType.ERROR,"error");
                alert.show();
            }

        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }



    private void cmbLoadData() throws SQLException, ClassNotFoundException {
        ArrayList<Employee> arrayList = EmployeeModel.loadEmployee();
        ObservableList obList= FXCollections.observableArrayList();
        for (Employee emp: arrayList) {
            obList.add(emp.getEID());
        }
        combEmployeeId.setItems(obList);
    }


    public void initialize() {
        try {
            cmbLoadData();
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

    public void btnSearch(ActionEvent actionEvent) {
        String search = Search.getText();
        lk.ijse.StudentMS.to.Student student = new Student();
        student.setSID(search);
        try {
            boolean searchStudent = StudentModel.searchStudent(student);
            if (searchStudent) {
                txtID.setText(search);
                txtNIC.setText(student.getNIC());
                txtStream.setText(student.getStream());
                txtEY.setText(student.getExam_year());
                txtName.setText(student.getName());
                txtAdress.setText(student.getAddress());
                txtCNo.setText(student.getContact());
                txtEmail.setText(student.getContact());
                Search.setText("");
            }else{
                Alert alert=new Alert(Alert.AlertType.ERROR,"error");
                alert.show();
            }

        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

    public void searchOnAction(ActionEvent actionEvent) {
    }
    public void clear(){
        txtID.clear();
        txtNIC.clear();
        txtStream.clear();
        txtEY.clear();
        txtName.clear();
        txtAdress.clear();
        txtCNo.clear();
        txtEmail.clear();
    }

    public void btnAddStudent(ActionEvent actionEvent) {

        lk.ijse.StudentMS.to.Student student = new Student(combEmployeeId.getValue(),txtID.getText(),txtName.getText(),txtEmail.getText(),
        txtEY.getText(),txtNIC.getText(),txtAdress.getText(),txtCNo.getText(),txtStream.getText());

        try {
            boolean isAdded = StudentModel.addStudent(student);

            if (isAdded) {
                new Alert(Alert.AlertType.CONFIRMATION, "Student Added!").show();
            } else {
                new Alert(Alert.AlertType.WARNING, "Something happened!").show();
            }
        } catch (SQLException | ClassNotFoundException x) {
            x.printStackTrace();
        }
    }

    public void btnDeleteStudent(ActionEvent actionEvent) {
    }
}
