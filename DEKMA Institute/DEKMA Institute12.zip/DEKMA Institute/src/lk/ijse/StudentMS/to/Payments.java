package lk.ijse.StudentMS.to;

public class Payments {
    private String SID;
    private String cardNo;
    private String amount;
    private String date;
    private String payment_months;
    private String time;

    public Payments() {
    }

    public Payments(String SID, String cardID, String amount, String date, String payment_months, String time) {
        this.SID = SID;
        cardNo = cardID;
        this.amount = amount;
        this.date = date;
        this.payment_months = payment_months;
        this.time = time;
    }

    public String getSID() {
        return SID;
    }

    public void setSID(String SID) {
        this.SID = SID;
    }

    public String getCardID() {
        return cardNo;
    }

    public void setCardID(String cardID) {
        cardNo = cardNo;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getPayment_months() {
        return payment_months;
    }

    public void setPayment_months(String payment_months) {
        this.payment_months = payment_months;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
