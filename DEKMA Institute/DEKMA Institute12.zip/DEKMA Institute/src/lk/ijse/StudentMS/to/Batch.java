package lk.ijse.StudentMS.to;

public class Batch {
    private String BID;
    private String year;

    public Batch() {
    }

    public Batch(String BID, String year) {
        this.BID = BID;
        this.year = year;
    }

    public String getBID() {
        return BID;
    }

    public void setBID(String BID) {
        this.BID = BID;
    }



    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }
}
