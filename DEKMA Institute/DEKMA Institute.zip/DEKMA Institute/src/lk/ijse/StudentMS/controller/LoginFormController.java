package lk.ijse.StudentMS.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.StudentMS.model.UserModel;
import lk.ijse.StudentMS.to.User;

import java.io.IOException;
import java.sql.SQLException;

public class LoginFormController {

    public AnchorPane pane;
    public TextField txtName;
    public TextField txtPassword;





    @FXML
//    void loginOnAction(ActionEvent event) throws IOException {
//        String password = txtPassword.getText();
//        String userName = txtName.getText();
//
//        User user=new User();
//        user.setUserName(userName);
//
//
//        try {
//            boolean checkUser = UserModel.checkUser(user);
//            if(checkUser) {
//                String DBrole = user.getRole();
//                String DBpassword = user.getPassword();
//
//
//                if (DBrole.equals("Admin")) {
//                    if (password.equals(DBpassword)) {
//                        Stage stage = (Stage) pane.getScene().getWindow();
//                        stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/lk/ijse/StudentMS/view/AdminForm.fxml"))));
//                        stage.show();
//                    }
//                } else if (DBrole.equals("Manager")) {
//                    Stage stage = (Stage) pane.getScene().getWindow();
//                    stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/lk/ijse/StudentMS/view/ManagerForm.fxml"))));
//                    stage.show();
//                } else if (DBrole.equals("Teacher")) {
//                    Stage stage = (Stage) pane.getScene().getWindow();
//                    stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/lk/ijse/StudentMS/view/TeacherForm.fxml"))));
//                    stage.show();
//                }
//            }
//
//        } catch (SQLException | ClassNotFoundException throwables) {
//            throwables.printStackTrace();
//        }
//
//
//
//
//       //loku form ain wela eke udta ekk load wenna
//        Stage stage= (Stage) pane.getScene().getWindow();
//        stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/lk/ijse/StudentMS/view/AdminForm.fxml"))));
//        stage.show();
//    }

    public void FogotPassword(ActionEvent actionEvent) {

    }

    public void CreateNAOnAction(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage) pane.getScene().getWindow();
        stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/lk/ijse/StudentMS/view/CreateAccountForm.fxml"))));
        stage.show();

    }


    public void LoginOnAction(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage) pane.getScene().getWindow();
        stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/lk/ijse/StudentMS/view/AdminForm.fxml"))));
        stage.show();
    }
//        String password = txtPassword.getText();
//        String userName = txtName.getText();
//
//        User user=new User();
//        user.setUID(userName);
//
//
//        try {
//            boolean checkUser = UserModel.checkUser(user);
//            if(checkUser) {
//                String DBrole = user.getRole();
//                String DBpassword = user.getPassword();
//
//
//                if (DBrole.equals("Admin")) {
//                    if (password.equals(DBpassword)) {
//                        Stage stage = (Stage) pane.getScene().getWindow();
//                        stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/lk/ijse/StudentMS/view/AdminForm.fxml"))));
//                        stage.show();
//                    }
//                } else if (DBrole.equals("Manager")) {
//                    Stage stage = (Stage) pane.getScene().getWindow();
//                    stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/lk/ijse/StudentMS/view/ManagerForm.fxml"))));
//                    stage.show();
//                } else if (DBrole.equals("Teacher")) {
//                    Stage stage = (Stage) pane.getScene().getWindow();
//                    stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/lk/ijse/StudentMS/view/TeacherForm.fxml"))));
//                    stage.show();
//                }
//            }
//
//        } catch (SQLException | ClassNotFoundException | IOException throwables) {
//            throwables.printStackTrace();
//        }
//
//    }
}
