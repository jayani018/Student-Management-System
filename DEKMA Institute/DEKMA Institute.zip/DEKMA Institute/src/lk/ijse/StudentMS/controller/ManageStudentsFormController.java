package lk.ijse.StudentMS.controller;

import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import lk.ijse.StudentMS.db.DBConnection;
import lk.ijse.StudentMS.model.EmployeeModel;
import lk.ijse.StudentMS.model.StudentAttendanceModel;
import lk.ijse.StudentMS.model.StudentModel;
import lk.ijse.StudentMS.model.SubjectModel;
import lk.ijse.StudentMS.to.Employee;
import lk.ijse.StudentMS.to.Student;
import lk.ijse.StudentMS.to.Subject;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class ManageStudentsFormController{

    public TableColumn Subjects;

    public TableColumn StudentId;
    public TableColumn NIC;
    public TableColumn Name;
    public TableColumn Address;
    public TableColumn Email;
    public TableColumn CNumber;
    public TableColumn EY;
    public AnchorPane pane;
    public TableView Student;
    public JFXTextField Search;
    public JFXTextField txtID;
    public JFXTextField txtNIC;
    public JFXTextField txtName;
    public JFXTextField txtAdress;
    public JFXTextField txtEmail;
    public JFXTextField txtCNo;
    public JFXTextField txtEY;
    public JFXTextField txtSubject;
    public JFXComboBox <String> combEmployeeId;
    public TextField text;

    public void btnAddStudent(ActionEvent actionEvent) throws IOException {
        String EmployeeId = combEmployeeId.getValue();
        String id = txtID.getText();
        String name = txtName.getText();
        String email = txtEmail.getText();
        String examYear = txtEY.getText();
        String NIC = txtNIC.getText();
        String address = txtAdress.getText();
        String contactNo = txtCNo.getText();
        String subject = txtSubject.getText();
        Student student = new Student(id,EmployeeId,NIC,subject,examYear,name,address,contactNo,email);
        try {
            boolean addStudent = StudentModel.addStudent(student);
            if (addStudent) {
                Alert alert=new Alert(Alert.AlertType.CONFIRMATION,"Student add is successful");
                alert.show();
            }else {
                Alert alert=new Alert(Alert.AlertType.ERROR,"Error");
                alert.show();
            }

        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }

    }

    public void btnUpdateStudent(ActionEvent actionEvent) {
        String employeeId =String.valueOf(combEmployeeId.getValue()) ;
        String studentId = txtID.getText();
        String NIC = txtNIC.getText();
        String subject = txtSubject.getText();
        String examYear = txtEY.getText();
        String name = txtName.getText();
        String address = txtAdress.getText();
        String contactNo = txtCNo.getText();
        String email = txtEmail.getText();

        Student student = new Student(studentId,employeeId,NIC,subject,examYear,name,address,contactNo,email);

        try {
            boolean updateStudent = StudentModel.updateStudent(student);
            if (updateStudent) {
                Alert alert=new Alert(Alert.AlertType.INFORMATION,"Update is successful");
                alert.show();
            }else{
                Alert alert=new Alert(Alert.AlertType.ERROR,"error");
                alert.show();
            }

        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

    public boolean btnDeleteStudent(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        DBConnection.getdBConnection().getConnection().setAutoCommit(false);
        String id = txtID.getText();
        Student student = new Student();
        student.setSID(id);
        try {
            boolean deleteStudent = StudentModel.deleteStudent(student);
            if (deleteStudent) {
                new Alert(Alert.AlertType.INFORMATION, "Delete is successful").show();
                clear();
                boolean deleteSubject = SubjectModel.deleteSubject(id);
                if (deleteSubject) {
                    boolean deleteAttendance = StudentAttendanceModel.deleteAttendance(id);
                    if (deleteAttendance) {
                        DBConnection.getdBConnection().getConnection().commit();
                        return true;
                    }
                }
            } else {
                new Alert(Alert.AlertType.ERROR, "Error").show();

            }
            DBConnection.getdBConnection().getConnection().rollback();
            return false;

        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();

           // DBConnection.getdBConnection().getConnection().rollback();


    } finally {
            DBConnection.getdBConnection().getConnection().setAutoCommit(true);
        }

        return false;

    }

    private void cmbLoadData() throws SQLException, ClassNotFoundException {
        ArrayList<Employee> arrayList = EmployeeModel.loadEmployee();
        for (Employee emp: arrayList) {
            combEmployeeId.getItems().add(emp.getEID());
        }
    }


    public void initialize() {
        try {
            cmbLoadData();
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

    public void btnSearch(ActionEvent actionEvent) {
        String search = Search.getText();
        Student student = new Student();
        student.setSID(search);
        try {
            boolean searchStudent = StudentModel.searchStudent(student);
            if (searchStudent) {
                txtID.setText(search);
                txtNIC.setText(student.getNIC());
                txtSubject.setText(student.getSubject());
                txtEY.setText(student.getExam_year());
                txtName.setText(student.getName());
                txtAdress.setText(student.getAddress());
                txtCNo.setText(student.getContact());
                txtEmail.setText(student.getContact());
                Search.setText("");
            }else{
                Alert alert=new Alert(Alert.AlertType.ERROR,"error");
                alert.show();
            }

        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

    public void searchOnAction(ActionEvent actionEvent) {
    }
    public void clear(){
        txtID.clear();
        txtNIC.clear();
        txtSubject.clear();
        txtEY.clear();
        txtName.clear();
        txtAdress.clear();
        txtCNo.clear();
        txtEmail.clear();
    }
}
