package lk.ijse.StudentMS.controller;

import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.StudentMS.model.EmployeeModel;
import lk.ijse.StudentMS.model.SubjectModel;
import lk.ijse.StudentMS.model.TeacherModel;
import lk.ijse.StudentMS.to.Employee;
import lk.ijse.StudentMS.to.Subject;
import lk.ijse.StudentMS.to.Teacher;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

public class ManageTeacherFormController {
    public AnchorPane pane;
    public TableView Teacher;
    public TableColumn TID;
    public TableColumn NIC;
    public TableColumn Name;
    public TableColumn Address;
    public TableColumn Email;
    public TableColumn CNumber;
    public TableColumn Salary;
    public JFXTextField Search;
    public JFXTextField txtId;
    public JFXTextField txtNIC;
    public JFXTextField txtSalary;
    public JFXTextField txtName;
    public JFXTextField txtEmail;
    public JFXTextField txtContactNo;
    public JFXTextField txtAddress;
    public JFXComboBox combSubId;

    public void btnAddTeacher(ActionEvent actionEvent) throws IOException {
        String subId = String.valueOf(combSubId.getValue());
        String id = txtId.getText();
        String NIC = txtNIC.getText();
        String name = txtName.getText();
        String address = txtAddress.getText();
        String contactNo = txtContactNo.getText();
        String email = txtEmail.getText();
        double salary = Double.parseDouble(txtSalary.getText());
        Teacher teacher = new Teacher(id, subId, NIC, name, address, contactNo, email, salary);
        try {
            boolean addTeacher = TeacherModel.addTeacher(teacher);
            if (addTeacher) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "added");
                alert.show();
            }

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

       /* Parent parent = FXMLLoader.load(getClass().getResource("/lk/ijse/StudentMS/view/SuccessfullForm.fxml.fxml"));
        pane.getChildren().clear();
        pane.getChildren().add(parent);*/
       /* Stage stage = (Stage) pane.getScene().getWindow();
        stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/lk/ijse/StudentMS/view/SuccessfulForm.fxml.fxml"))));
        stage.show();*/

    }

    public void btnUpdateTeacher(ActionEvent actionEvent) {
        String subjectId = String.valueOf(combSubId.getValue());
        String studentId = txtId.getText();
        String NIC = txtNIC.getText();
        String name = txtName.getText();
        String address = txtAddress.getText();
        String contactNo = txtContactNo.getText();
        String email = txtEmail.getText();
        double salary = Double.parseDouble(txtSalary.getText());

        Teacher teacher = new Teacher(studentId, subjectId, NIC, name, address, contactNo, email, salary);

        try {
            boolean updateTeacher = TeacherModel.updateTeacher(teacher);
            if (updateTeacher) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Update is successful");
                alert.show();
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR, "error");
                alert.show();
            }

        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

    public void btnDeleteTeacher(ActionEvent actionEvent) {
            String TID = txtId.getText();
            Teacher teacher = new Teacher();
            teacher.setTID(TID);
            try {
                boolean deleteTeacher = TeacherModel.deleteTeacher(teacher);
                if (deleteTeacher) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION, "Delete is successful");
                    alert.show();
                    txtId.setText(null);
                    txtNIC.setText(null);
                    txtName.setText(null);
                    txtAddress.setText(null);
                    txtContactNo.setText(null);
                    txtEmail.setText(null);
                    txtSalary.setText(null);

                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR, "Error");
                    alert.show();
                }

            } catch (SQLException | ClassNotFoundException throwables) {
                throwables.printStackTrace();
            }
        }


      /*  private void cmbLoadData () {
            try {

                ArrayList<Subject> arrayList = SubjectModel.loadSubject();

                String[] teacher = new String[arrayList.size()];

                for (int i = 0; i < arrayList.size(); i++) {
                    SubjectIds[i] = arrayList.get(i).getSUBID();
                }

                combSubId.getItems().setAll(SubjectIds);

            } catch (SQLException | ClassNotFoundException throwables) {
                throwables.printStackTrace();
            }
        }
        public void initialize () {
            cmbLoadData();
        }*/


        public void btnSearch (ActionEvent actionEvent){
            String search = Search.getText();
            Teacher teacher = new Teacher();
            teacher.setTID(search);
            try {
                boolean searchTeacher = TeacherModel.searchTeacher(teacher);
                if (searchTeacher) {
                    txtId.setText(search);
                    txtNIC.setText(teacher.getNIC());
                    txtName.setText(teacher.getName());
                    txtAddress.setText(teacher.getAddress());
                    txtContactNo.setText(teacher.getContact());
                    txtEmail.setText(teacher.getEmail());
                    txtSalary.setText(String.valueOf(teacher.getSalary()));
                    Search.setText("");
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR, "error");
                    alert.show();
                }

            } catch (SQLException | ClassNotFoundException throwables) {
                throwables.printStackTrace();
            }
        }


    private void cmbLoadData() throws SQLException, ClassNotFoundException {
        ArrayList<Employee> arrayList = EmployeeModel.loadEmployee();
        for (Employee emp : arrayList) {
            combSubId.getItems().add(emp.getEID());
        }
    }

    public void initialize() {
        try {
            cmbLoadData();
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }
}