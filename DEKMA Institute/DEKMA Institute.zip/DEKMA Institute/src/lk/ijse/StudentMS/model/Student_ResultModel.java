/*package lk.ijse.StudentMS.model;

import lk.ijse.StudentMS.db.DBConnection;

public class Student_ResultModel {
        public static boolean studentResult(Result result) throws SQLException, ClassNotFoundException {
            try {
                DBConnection.getInstance().getConnection().setAutoCommit(false);
                boolean isresultAdded = Student_ResultModel.save(new Order(placeOrder.getOrderId(), LocalDate.now(), placeOrder.getCustomerId()));
                if (isOrderAdded) {
                    boolean isUpdated = ItemModel.updateQty(placeOrder.getOrderDetails());
                    if (isUpdated) {
                        boolean isOrderDetailAdded = OrderDetailModel.saveOrderDetails(placeOrder.getOrderDetails());
                        if (isOrderDetailAdded) {
                            DBConnection.getInstance().getConnection().commit();
                            return true;
                        }
                    }
                }
                DBConnection.getInstance().getConnection().rollback();
                return false;
            } finally {
                DBConnection.getInstance().getConnection().setAutoCommit(true);
            }
        }
    }

}*/
