package lk.ijse.StudentMS.tm;

public class SubjectTm {
    String subId;
    String subName;

    public SubjectTm(String subId, String subName) {
        this.subId = subId;
        this.subName = subName;
    }

    public SubjectTm() {
    }

    public String getSubId() {
        return subId;
    }

    public void setSubId(String subId) {
        this.subId = subId;
    }

    public String getSubName() {
        return subName;
    }

    public void setSubName(String subName) {
        this.subName = subName;
    }

    @Override
    public String toString() {
        return "SubjectTm{" +
                "subId='" + subId + '\'' +
                ", subName='" + subName + '\'' +
                '}';
    }
}
