package lk.ijse.StudentMS.to;

public class User {

    private String EId;
    private String userName;
    private String password;

    public User() {
    }

    public User(String EId, String userName, String password) {
        this.EId = EId;
        this.userName = userName;
        this.password = password;
    }

    public String getEId() {
        return EId;
    }

    public void setEId(String EId) {
        this.EId = EId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
